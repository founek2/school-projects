#include <iostream>
#include <vector>
#include <algorithm>
#include <chrono>

#include "common.cpp"
#include "loaders.cpp"
#include "checkers.cpp"

#define TASK_SIZE 30

using namespace std;

int nodeCount = 0;
int bestWeight = 0;
uint callCounter = 0;

Result findSolutions(Edge usedEdge, int8_t variant, vector<Node> nodes, Edges edges, Edges acc) {
    ++callCounter;
    if (bestWeight > edges.weight + acc.weight)
        return {};


    if (!setColor(variant, usedEdge.nodes, nodes))
        return {};


    if (edges.data.empty()) {
        if (!isCoherent(acc, nodeCount))
            return {};

        Result list{.weight=acc.weight, .data={acc.data}};
        if (list.weight > bestWeight) {
#pragma omp atomic write
            bestWeight = list.weight;
            cout << "found " << bestWeight << ", called: " << callCounter << endl;
        }

        return list;
    }

    Edge edge = pop(edges);
    Result result1, result2, result3;

    acc = push(edge, acc);

#pragma omp task shared(result2, bestWeight, callCounter) if (edges.data.size() >TASK_SIZE)
    result2 = findSolutions(edge, RED, nodes, edges, acc);
#pragma omp task  shared(result3, bestWeight, callCounter) if (edges.data.size() >TASK_SIZE)
    result3 = findSolutions(edge, BLACK, nodes, edges, acc);

    pop(acc);
#pragma omp task  shared(result1, bestWeight, callCounter) if (edges.data.size() >TASK_SIZE)
    result1 = findSolutions(Edge{}, NONE, nodes, edges, acc);

#pragma omp taskwait
    return mergeSolutions(result1, result2, result3);
}

Result startSearch(vector<Node> &nodes, Edges &edges, Edges &acc) {
    if (nodes.empty()) return {};
    nodes[0].color = BLACK;

    Result result;

#pragma omp parallel default(shared)
    {
#pragma omp single
        result = findSolutions(Edge{}, NONE, nodes, edges, acc);
    }

    return result;
}

void testCase() {
    Edges acc;
    nodeCount = 3;

    Edges edges;
    edges.weight = 500;
    edges.data.push_back(Edge{.weight=100, .nodes={0, 1}});
    edges.data.push_back(Edge{.weight=100, .nodes={1, 2}});
    edges.data.push_back(Edge{.weight=100, .nodes={2, 0}});

    vector<Node> nodes(nodeCount);
    auto results = startSearch(nodes, edges, acc);
    printResults(results);

    cout << "called: " << callCounter << endl;
}

int main(int argc, char *argv[]) {
    //testCase();
    //return 0;

    if (argc < 2) {
        cerr << "Missing argument: provide path to input file";
        return 1;
    } else if (argc > 2) {
        cerr << "Too many arguments";
        return 1;
    }
    char *file_path = argv[1];

    vector<int> matrix = loadMatrix(file_path, nodeCount);
    Edges edges = loadEdges(matrix, nodeCount);
    sort(edges.data.begin(), edges.data.end(), cmpDescending);

    //printEdges(edges);

    vector<Node> nodes(nodeCount);

    auto neighbours = loadNeighbours(matrix, nodeCount);
    bool bipartite = isBipartite(nodes, neighbours);
    cout << "isBipartite=" << bipartite << endl;

    auto start = getTime();

    Edges acc;
    Result results = startSearch(nodes, edges, acc);
    printResults(results);

    auto end = getTime();

    cout << endl << "Measurements:" << endl;
    cout << "called: " << callCounter << endl;
    cout << "passed: " << end - start << " ms" << endl;
    cout << "passed: " << (end - start) / 1000 << " s" << endl;

    return 0;
}