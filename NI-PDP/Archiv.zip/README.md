# NI-PDP

|               | 10_7 | 12_6 | 15_5 |
|---------------|------|------|------|
| Sequential    | 4,2  | 4,2  | 6,1  |
| Task parallel | 1,6  | 5,1  | 3,9  |
| Data parallel | 1,3  | 1,1  | 1,8  |
| mpi parallel  | 1,3  | 3    | 3    |

> measured (unit seconds) running in Docker with 4 cores assigned, HW: Mac Air M1