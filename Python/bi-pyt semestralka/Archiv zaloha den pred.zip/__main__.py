if __name__ == '__main__':
    from src.program import main

    main()
