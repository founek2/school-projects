class MyError(BaseException):
    pass
